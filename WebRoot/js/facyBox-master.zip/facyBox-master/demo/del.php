<?php

sleep(5);

?>
I'm remote.html, a different file loaded with ajax, with 5 sec delay.
